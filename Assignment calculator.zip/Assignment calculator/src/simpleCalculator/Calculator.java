package simpleCalculator;
import java.util.Scanner;
public class Calculator{
    public static void main(String[] args)
    {
    Scanner sc = new Scanner(System.in);
    
    System.out.println("Calculator");
    System.out.println("1.Addition");
    System.out.println("2.subtracton");
    System.out.println("3.Multiplication");
    System.out.println("4.Division");
    int choice = sc.nextInt();

    
    if(choice == 1){
    add();}
    else if(choice == 2){
    sub();}
    else if(choice == 3){
    mul();}
    else if(choice == 4){
    div();}
    else 
    System.out.println("Invalid choice");
    sc.close();
    }
    static void add()
    {
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Enter the first number to be added");
        int a = sc.nextInt();
        System.out.println("Enter the second number to be added");
        int b = sc.nextInt();
        
        System.out.println("Result=" +a+ "+" +b+ "=" +(a + b));
        sc.close();  
    }
     static void sub()
    {
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Enter the first number to be subtract");
        int a = sc.nextInt();
        System.out.println("Enter the second number to be subtract");
        int b = sc.nextInt();
        
        System.out.println("Result=" +a+ "-" +b+ "=" +(a - b));
        sc.close();
    }
     static void mul()
    {
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Enter the first number to multiply");
        int a = sc.nextInt();
        System.out.println("Enter the second number to be multiply");
        int b = sc.nextInt();
    
        System.out.println("Result=" +a+ "*" +b+ "=" +(a * b));
        sc.close();
    }
     static void div()
    {
        Scanner sc = new Scanner(System.in);
        try {
        System.out.println("Enter the first number to be divide");
        int a = sc.nextInt();
        System.out.println("Enter the second number to be divide");
        int b = sc.nextInt();
        int c = a/b;
       
        	System.out.println("Result=" +c);
         }
        catch(ArithmeticException ae) {
        	System.out.println("Arithmetic Exception occured");
        }
        sc.close();
        }
}      
          

